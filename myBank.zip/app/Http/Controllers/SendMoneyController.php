<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SendMoneyController extends Controller
{
    public function index()
    {
        return view('frontend.operations.sendingOptions');
    }
}
