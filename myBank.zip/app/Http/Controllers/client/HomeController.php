<?php

namespace App\Http\Controllers\client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function policy()
    {
        return view('frontend.policy');
    }
    public function notifications()
    {
        return view('frontend.notifications');
    }
}
