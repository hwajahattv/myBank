<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use RealRashid\SweetAlert\Facades\Alert;


class PaymentController extends Controller
{
    public function index()
    {
        return view('frontend.operations.paymentOptions');
    }
    public function viaEmail()
    {
        return view('frontend.operations.payViaEmail');
    }
    public function pay(Request $request)
    {

        $request->validate([
            'amount' => 'required',
            //            'surName' => 'required|max:25',
            'email' => 'required',
            'pin' => 'required|exists:pins,pin',
        ]);
        $userEmail = Auth::user()->email;
        $user = DB::table('users')
            ->leftJoin('accounts as a', 'a.user_id', '=', 'users.id')
            ->where(['email' => $userEmail])->get();
        // dd($user);
        $balance = $user[0]->credit - $request['amount'];
        $status1 = Account::where(['account_number' => $user[0]->account_number])->update(['credit' => $balance]);
        // dd($status);
        $targetEmail = $request['email'];
        $targetUser = DB::table('users')
            ->leftJoin('accounts as a', 'a.user_id', '=', 'users.id')
            ->where(['email' => $targetEmail])->get();
        $balance = $targetUser[0]->credit + $request['amount'];
        $status2 = Account::where(['account_number' => $targetUser[0]->account_number])->update(['credit' => $balance]);
        // dd($status);
        if ($status1 && $status2) {
            Alert::success('Successfull!', 'Payment made successfully.');
            return redirect()->route('client.dashboard');
        }
    }
}
