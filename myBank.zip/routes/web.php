<?php

// use App\Http\Controllers\AccountController;
use App\Http\Controllers\admin\AccountController;
use App\Http\Controllers\admin\TransactionController;
use App\Http\Controllers\admin\AdminController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\client\AuthController;
use App\Http\Controllers\client\HomeController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\PinController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\SendMoneyController;
use App\Http\Controllers\TransferController;
use App\Http\Controllers\UserController;
use App\Http\Middleware\AdminAuthenticate;
use App\Http\Middleware\ClientAuthenticate;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('frontend.landing');
})->name('client.landingPage');
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::post('/save_image', [ProfileController::class, 'saveImage']);

    // Money transfer routes
    Route::get('transfer', [TransferController::class, 'index'])->name('transfer.index');
});

// admin routes
Route::get('/admin/login', [AdminController::class, 'login'])->name('admin.login');
Route::get('/admin', function () {
    return redirect()->route('admin.login');
});
Route::post('/admin/login', [AuthenticatedSessionController::class, 'store'])->name('admin.login.store')->middleware(AdminAuthenticate::class);

Route::middleware(['auth', 'user-access:user'])->group(function () {
    Route::get('/home', [AdminController::class, 'index'])->name('home');
    Route::resource('account', AccountController::class);
    Route::resource('user', UserController::class);
    // Route::get('/user/delete/{id}', UserController::class, 'destroy')
    //     ->name('user.delete');
    Route::resource('transaction', TransactionController::class);
    Route::post('/transaction/find', [TransactionController::class, 'find'])->name('find.transaction');
    Route::get('/admin/dashboard', [AdminController::class, 'index'])->name('admin.dashboard');
});

// Client routes
Route::get('/client/auth', [AuthController::class, 'auth'])->name('client.auth');
Route::get('/client/login', [AuthController::class, 'login'])->name('client.login');
Route::get('/client/register', [AuthController::class, 'register'])->name('client.register');
Route::get('/client/forgot-password', [AuthController::class, 'forgotPassword'])->name('client.forgot-password');
Route::post('/client/login', [AuthenticatedSessionController::class, 'store'])->name('client.login.store')->middleware(ClientAuthenticate::class);
Route::middleware(['auth'])->group(function () {

    Route::get('/client/dashboard', [AuthController::class, 'dashboard'])->name('client.dashboard');
    Route::get('/client', [AuthController::class, 'profile'])->name('client.profile');

    // banking operations routes
    Route::get('/send/index', [SendMoneyController::class, 'index'])->name('sendMoney.index');
    Route::get('/send/viaEmail', [SendMoneyController::class, 'viaEmail'])->name('send.viaEmail');
    Route::post('/send/viaEmail', [SendMoneyController::class, 'pay'])->name('send.viaEmail');

    Route::get('/pay/index', [PaymentController::class, 'index'])->name('payment.index');
    Route::get('/pay/viaEmail', [PaymentController::class, 'viaEmail'])->name('payment.viaEmail');
    Route::post('/pay/viaEmail', [PaymentController::class, 'pay'])->name('payment.viaEmail');

    Route::get('/generate/PIN', [PinController::class, 'create'])->name('pin.create');
    Route::post('/account/viaEmail', [AccountController::class, 'viaEmail'])->name('account.viaEmail');


    // misc routes on client side
    Route::get('/client/policy', [HomeController::class, 'policy'])->name('client.policy');
    Route::get('/client/notifications', [HomeController::class, 'notifications'])->name('client.notifications');
});
require __DIR__ . '/auth.php';
