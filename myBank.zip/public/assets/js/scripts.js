(function($) {
    $(function() {

        $(document).ready(function() {

            if ($('.parallax').length) {
                $('.parallax').parallax();
            }
        });
    }); // end of document ready
})(jQuery);