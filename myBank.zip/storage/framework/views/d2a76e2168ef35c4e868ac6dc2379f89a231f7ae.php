
<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-around">
    <a href="<?php echo e(route('transfer.index')); ?>">

        <div class="card text-white bg-success" style="max-width: 250px; border-radius: 20px">
            <img class="card-img-top" width="200px" src="<?php echo e(asset('public/assets/images/wallet.png')); ?>" alt="Title">
            <div class="card-body">
                <h4 class="card-title text-center">Add Money</h4>
                
            </div>
        </div>
    </a>
    <a href="">
        <div class="card text-white bg-success" style="max-width: 250px; border-radius: 20px">
            <img class="card-img-top" src="<?php echo e(asset('public/assets/images/withdrawal.png')); ?>" alt="Title">

            <div class="card-body">
                <h4 class="card-title text-center">Withdraw Money</h4>
                
            </div>
        </div>
    </a>
    <a href="">
        <div class="card text-white bg-success" style="max-width: 250px; border-radius: 20px">
            <img class="card-img-top" width="200px" src="<?php echo e(asset('public/assets/images/investment.png')); ?>" alt="Title">


            <div class="card-body">
                <h4 class="card-title text-center">Invest Money</h4>
                
            </div>
        </div>
    </a>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mobileUI.parent.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UL_work_folder\myBank\resources\views/mobileUI/home.blade.php ENDPATH**/ ?>