

<?php $__env->startSection('style'); ?>
<style>
    html {
        background-color: #000056;
    }

    * {
        margin: 0;
        padding: 0;
    }

    .main {
        padding: 200px 0px;
        width: 100%;
        height: 100%;
        background-color: #000056;
        color: white;
        text-align: center;
        display: inline-block;

    }

    .content {
        padding: 10px;
        background-color: #ff0017;
        border-radius: 50%;
    }

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="hero">
    <h1><span class="content">my</span> Bank</h1>
</div>
<div>
    <a class="btn btn-primary btn-lg m-4" href="<?php echo e(route('client.auth')); ?>">Get Started</a>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UL_work_folder\myBank\resources\views/frontend/landing.blade.php ENDPATH**/ ?>