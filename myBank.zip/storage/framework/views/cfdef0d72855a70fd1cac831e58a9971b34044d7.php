Dear Customer,

Your One Time Password (OTP) for the internet transaction through your MyBank Account is <?php echo e($pin); ?>. This OTP is Valid for next 10 minutes.

Please call our MyBank helpline at +745845225522151 , if you have not initiated an online transaction.

Yours sincerely
MyBank Team

This email and any attachments are confidential and may also be privileged. If you are not the intended recipient, please delete all copies and notify the sender immediately.
<?php /**PATH E:\UL_work_folder\myBank\resources\views/admin/emails/otp.blade.php ENDPATH**/ ?>