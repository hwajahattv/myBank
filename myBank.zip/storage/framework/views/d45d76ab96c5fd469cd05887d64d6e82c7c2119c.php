    
    <?php $__env->startSection('content'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <div class="container-scroller">
        <div class="container-fluid page-body-wrapper full-page-wrapper">
            <div class="content-wrapper d-flex align-items-center auth">
                <div class="row flex-grow">
                    <div class="col-lg-4 mx-auto">
                        <div class="auth-form-light text-left p-5">
                            <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            <div class="brand-logo d-flex justify-content-center">
                                <img src="<?php echo e(asset('/public/assets/admin/images/logo.png')); ?>">
                            </div>
                            <h4 class="text-center">Administrator login</h4>
                            <h6 class="font-weight-light">Sign in</h6>
                            <form class="pt-3" method="POST" action="<?php echo e(route('admin.login.store')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <input name="email" type="email" class="form-control form-control-lg" id="exampleInputEmail1" placeholder="Email">
                                    <?php if($errors->has('email')): ?>
                                    <span class="text-danger" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?>.</strong>
                                    </span>
                                    <?php endif; ?>

                                </div>
                                <div class="form-group">
                                    <input name="password" required type="password" class="form-control form-control-lg" id="exampleInputPassword1" placeholder="Password">
                                    <?php if($errors->has('password')): ?>
                                    <span class="invalid feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?>.</strong>

                                    </span>
                                    <?php endif; ?>

                                </div>
                                <div class="mt-3">
                                    <button class="btn btn-block btn-dark btn-lg font-weight-medium auth-form-btn" type="submit">SIGN IN</button>
                                </div>
                                <div class="my-2 d-flex justify-content-between align-items-center">
                                    <div class="form-check">
                                        <label class="form-check-label text-muted">
                                            <input type="checkbox" class="form-check-input" name="remember"> Remember me </label>
                                    </div>
                                    <?php if(Route::has('password.request')): ?>
                                    <a href="<?php echo e(route('password.request')); ?>" class="auth-link text-black">Forgot password?</a>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="text-center mt-4 font-weight-light"> Don't have an account? <a href="<?php echo e(route('register')); ?>" class="text-primary">Create</a>

                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- content-wrapper ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UL_work_folder\myBank\resources\views/auth/adminLogin.blade.php ENDPATH**/ ?>