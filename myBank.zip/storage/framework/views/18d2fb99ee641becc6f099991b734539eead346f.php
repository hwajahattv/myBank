Hello Admin,<br><br>


New user is registered and his/her account is opened successfully. The account credentials are:<br>
Full name: <?php echo e($name); ?><br>
Email: <?php echo e($email); ?><br>
Account number: <?php echo e($account_number); ?><br>
Account Title: <?php echo e($title); ?><br>
<br>

Thank You,<br>
MyBank Team.
<?php /**PATH E:\UL_work_folder\myBank\resources\views/admin/emails/account_created_admin.blade.php ENDPATH**/ ?>