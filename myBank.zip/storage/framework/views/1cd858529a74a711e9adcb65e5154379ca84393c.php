Hello <?php echo e($name); ?>,<br><br>

Welcome to MyBank.<br><br>
You account is opened successfully. Your account credentials are:<br>

Account number: <?php echo e($account_number); ?><br>

Account Title: <?php echo e($title); ?><br>
<br>

Thank You,<br>
MyBank Team.
<?php /**PATH E:\UL_work_folder\myBank\resources\views/admin/emails/register_client.blade.php ENDPATH**/ ?>