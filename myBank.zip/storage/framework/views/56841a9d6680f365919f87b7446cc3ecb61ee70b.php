<section class="footers">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="foot">
                    <ul class="footer_ul">
                        <li>
                            <a href="<?php echo e(route('client.dashboard')); ?>">

                                <i class="fa fa-home fa-2x" aria-hidden="true"></i>
                                <p>home</p>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-life-ring fa-2x" aria-hidden="true"></i>
                                <p>Save</p>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="fa fa-briefcase fa-2x" aria-hidden="true"></i>
                                <p>Portfolio</p>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-reddit fa-2x" aria-hidden="true"></i>
                                <p>Reward</p>
                            </a>
                        </li>

                        <li>
                            <a href="#">
                                <i class="fa fa-user fa-2x" aria-hidden="true"></i>
                                <p>Account</p>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

</section>
<?php /**PATH E:\UL_work_folder\myBank\resources\views/frontend/components/footer.blade.php ENDPATH**/ ?>