
<?php $__env->startSection('content'); ?>
<div class="container d-flex justify-content-center">
    <a href="">
        <div class="card text-white" style="max-width: 75%; border-radius: 20px">
            <img class="card-img-top" width="200px" src="assets/images/wallet.png" alt="Title">
            <div class="card-body">
                <h4 class="card-title text-center">Add Money</h4>
                
            </div>
        </div>
    </a>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('mobileUI.parent.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UL_work_folder\myBank\resources\views/mobileUI/send.blade.php ENDPATH**/ ?>