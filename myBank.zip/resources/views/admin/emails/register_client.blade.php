Hello {{ $name }},<br><br>

Welcome to MyBank.<br><br>
You account is opened successfully. Your account credentials are:<br>

Account number: {{$account_number}}<br>

Account Title: {{$title}}<br>
<br>

Thank You,<br>
MyBank Team.
