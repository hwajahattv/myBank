Dear Customer,<br>

Your One Time Password (OTP) for the internet transaction through your MyBank Account is {{$pin}}. This OTP is Valid for next 10 minutes.<br>

<br>
<br>

Please call our MyBank helpline at +745845225522151 , if you have not initiated an online transaction.<br>
<br>
<br>


Yours sincerely<br>

MyBank Team<br>


This email and any attachments are confidential and may also be privileged. If you are not the intended recipient, please delete all copies and notify the sender immediately.
