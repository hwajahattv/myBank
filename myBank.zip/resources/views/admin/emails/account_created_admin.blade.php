Hello Admin,<br><br>


New user is registered and his/her account is opened successfully. The account credentials are:<br>
Full name: {{$name}}<br>
Email: {{$email}}<br>
Account number: {{$account_number}}<br>
Account Title: {{$title}}<br>
<br>

Thank You,<br>
MyBank Team.
