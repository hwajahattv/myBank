@extends('mobileUI.parent.master')
@section('content')
<div class="container d-flex justify-content-center">
    <a href="">
        <div class="card text-white" style="max-width: 75%; border-radius: 20px">
            <img class="card-img-top" width="200px" src="assets/images/wallet.png" alt="Title">
            <div class="card-body">
                <h4 class="card-title text-center">Add Money</h4>
                {{-- <p class="card-text">Text</p> --}}
            </div>
        </div>
    </a>

</div>

@endsection
